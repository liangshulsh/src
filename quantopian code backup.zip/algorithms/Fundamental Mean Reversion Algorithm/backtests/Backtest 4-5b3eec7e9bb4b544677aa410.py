

import numpy as np
import pandas as pd
import datetime

        
def initialize(context):

    set_asset_restrictions(security_lists.restrict_leveraged_etfs)
    
    schedule_function(rebalance,
        date_rule=date_rules.month_start(),
        time_rule=time_rules.market_open(minutes = 20))

    schedule_function(buy,
        date_rule=date_rules.every_day(),
        time_rule=time_rules.market_open(minutes = 30))

    schedule_function(display,
        date_rule=date_rules.every_day(),
        time_rule=time_rules.market_close())

    context.m = sid(24744)
    context.bonds = [sid(23921)]
    
    context.start = True
    context.last_month = -1

    
def before_trading_start(context, data):
    
    month = get_datetime().month
    if context.last_month == month:
        return
    context.last_month = month

    df = get_fundamentals(
        query(fundamentals.valuation_ratios.ev_to_ebitda,
            fundamentals.valuation_ratios.sales_yield,
            fundamentals.operation_ratios.roic)
        .filter(fundamentals.company_reference.primary_exchange_id.in_(["NYSE", "NYS"]))
        .filter(fundamentals.operation_ratios.total_debt_equity_ratio != None)
        .filter(fundamentals.valuation.market_cap != None)
        .filter(fundamentals.valuation.shares_outstanding != None)  
        .filter(fundamentals.company_reference.primary_exchange_id != "OTCPK") # no pink sheets
        .filter(fundamentals.company_reference.primary_exchange_id != "OTCBB") # no pink sheets
        .filter(fundamentals.asset_classification.morningstar_sector_code != None) # require sector
        .filter(fundamentals.asset_classification.morningstar_sector_code != 103) # exclude financial sector
        .filter(fundamentals.asset_classification.morningstar_sector_code != 207) # exclude utilities sector
        .filter(fundamentals.share_class_reference.security_type == 'ST00000001') # common stock only
        .filter(~fundamentals.share_class_reference.symbol.contains('_WI')) # drop when-issued
        .filter(fundamentals.share_class_reference.is_primary_share == True) # remove ancillary classes
        .filter(((fundamentals.valuation.market_cap*1.0) / (fundamentals.valuation.shares_outstanding*1.0)) > 1.0)  # stock price > $1
        .filter(fundamentals.share_class_reference.is_depositary_receipt == False) # !ADR/GDR
        .filter(fundamentals.valuation.market_cap >= 5.0E+09)
        .filter(~fundamentals.company_reference.standard_name.contains(' LP')) # exclude LPs
        .filter(~fundamentals.company_reference.standard_name.contains(' L P'))
        .filter(~fundamentals.company_reference.standard_name.contains(' L.P'))
        .filter(fundamentals.balance_sheet.limited_partnership == None) # exclude LPs
        .order_by(fundamentals.valuation.market_cap.desc())
        .limit(500)).T
    
    context.score = pd.Series(np.zeros(len(df.index)), index = df.index)
    
    # EV/EBITDA, in-order (lower is better), nan goes last
    context.score += df['ev_to_ebitda'].\
    rank(ascending = True, na_option = 'bottom')
    
    # sales yield, inverse (higher is better), nan goes last
    context.score += df['sales_yield'].\
    rank(ascending = False, na_option = 'top')
    
    # return on invested capital, inverse (higher is better), nan goes last
    context.score += df['roic'].\
    rank(ascending = False, na_option = 'top')
    
    
def rebalance(context, data):

    P = data.history(context.score.index, 'price', 100, '1d')
    V = data.history(context.score.index, 'volume', 100, '1d')
    
    w = P * V
    w = w.mean()
    w = w[w > 10E+06]
    
    context.score = context.score[w.index]   
    context.longs = context.score.dropna().order().head(20).index   
    
    P = data.history(context.m, 'price', 200, '1d')
    if P.tail(2).median() < P.tail(200).median() or\
       P.tail(10).median() < P.tail(100).median():
        context.longs = context.bonds 

        
def buy(context,data):
    
    for s in context.portfolio.positions:
        if s in context.longs:
            continue
        if not data.can_trade(s):
            continue
        order_target(s, 0)    
    
    if get_open_orders():
        return    
    
    for s in context.longs:
        if not data.can_trade(s):
            continue
        order_value(s, context.portfolio.cash / len(context.longs))

        
def display(context,data):
    
    record(leverage = context.account.leverage,
           exposure = context.account.net_leverage)
    
                                 
def handle_data(context, data):
    
    if context.start:
        rebalance(context, data)
        buy(context, data)
        display(context, data)
        context.start = False

