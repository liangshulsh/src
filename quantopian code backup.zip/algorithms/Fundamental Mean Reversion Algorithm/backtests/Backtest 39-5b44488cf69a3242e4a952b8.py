import numpy as np
import pandas as pd
import datetime
from quantopian.pipeline import Pipeline
from quantopian.pipeline import CustomFactor
from quantopian.algorithm import attach_pipeline, pipeline_output
from quantopian.pipeline.data.builtin import USEquityPricing
from quantopian.pipeline.factors import SimpleMovingAverage, AverageDollarVolume
from quantopian.pipeline.data import morningstar
from quantopian.pipeline.filters import Q500US,Q3000US,Q1500US,QTradableStocksUS
from quantopian.pipeline.data import Fundamentals
        
def initialize(context):

    set_asset_restrictions(security_lists.restrict_leveraged_etfs)
    
    schedule_function(rebalance,
        date_rule=date_rules.month_start(),
        time_rule=time_rules.market_open(minutes = 20))

    schedule_function(buy,
        date_rule=date_rules.every_day(),
        time_rule=time_rules.market_open(minutes = 30))

    schedule_function(display,
        date_rule=date_rules.every_day(),
        time_rule=time_rules.market_close())

    context.m = sid(24744)
    context.bonds = [sid(23921)]
    
    context.start = True
    context.last_month = -1
    attach_pipeline(my_pipeline(context), 'my_pipeline')

class Sector(CustomFactor):
    inputs=[morningstar.asset_classification.morningstar_sector_code]
    window_length=1
    
    def compute(self, today, assets, out, sector):
        out[:] = sector[-1]   
  
def my_pipeline(context):
    """
    The original algorithm used the following filters:
        1. common stock
        2 & 3. not limited partnership - name and database check
        4. database has fundamental data
        5. not over the counter
        6. not when issued
        7. not depository receipts
        8. primary share
        9. high dollar volume
    Check Scott's notebook for more details.
    
    This updated version uses Q1500US, one of the pipeline's built-in base universes. 
    Lesson 11 from the Pipeline tutorial offers a great overview of using multiple 
    filters vs using the built-in base universes:
    https://www.quantopian.com/tutorials/pipeline#lesson11
    
    More detail on the selection criteria of this filter can be found  here:
    https://www.quantopian.com/posts/the-q500us-and-q1500us 
    """
    
    
    #is_basic_materials = Sector().eq(101)
    #is_consumer_cyclical = Sector().eq(102)
    is_financial_services = Sector().eq(103)
    #is_real_estate = Sector().eq(104)
    #is_consumer_defensive = Sector().eq(205)
    #is_healthcare = Sector().eq(206)
    is_utilities = Sector().eq(207)
    #is_communication_services = Sector().eq(308)
    #is_energy = Sector().eq(309)
    #is_industrials = Sector().eq(310)    
    #is_technology = Sector().eq(311)
    ev_to_ebitda = Fundamentals.ev_to_ebitda.latest
    sales_yield = Fundamentals.sales_yield.latest
    roic = Fundamentals.roic.latest
    market_cap = Fundamentals.market_cap.latest
    base_universe = Q3000US() #& ~is_financial_services & ~is_utilities
    total_assets = Fundamentals.total_assets.latest
    gross_profit = Fundamentals.gross_profit.latest
    pb_ratio = Fundamentals.pb_ratio.latest
    #roe = Fundamentals.roe.latest
    #ipo_date = Fundamentals.ipo_date.latest
    #pe_ratio = Fundamentals.pe_ratio.latest
    #pb_ratio = Fundamentals.pb_ratio.latest
    #ps_ratio = Fundamentals.ps_ratio.latest
    #current_assets = Fundamentals.current_assets.latest
    #current_liabilities = Fundamentals.current_liabilities.latest
    #net_assets = Fundamentals.net_assets.latest
    #market_cap = Fundamentals.market_cap.latest
    #roe = Fundamentals.roe.latest
    # The example algorithm - mean reversion. Note the tradable filter used as a mask.
    sma_10 = SimpleMovingAverage(inputs=[USEquityPricing.close], window_length=10,
                                 mask=base_universe)
    sma_30 = SimpleMovingAverage(inputs=[USEquityPricing.close], window_length=30,
                                 mask=base_universe)
    rel_diff = (sma_10 - sma_30) / sma_30
    
    top_rel_diff = rel_diff.top(500) 
    
    dollar_volume = AverageDollarVolume(window_length=200, mask=base_universe)
    
    my_pipe = Pipeline(
              columns={
                'ev_to_ebitda': ev_to_ebitda,
                'sales_yield': sales_yield,
                #'ps': ps_ratio,
                'market_cap': market_cap,
                'roic': roic,
                'gp': gross_profit / total_assets,
                'pb': pb_ratio
                #'liq': net_assets / total_assets
                #'ipo_date': ipo_date
                #'GM': gross_profit / market_cap
                #'roe': roe
              },
              screen = base_universe
          )
    #bottom_rel_diff = rel_diff.bottom(250)
    #my_pipe.add(bottom_rel_diff, 'bottom_rel_diff')
     
    return my_pipe
    
def before_trading_start(context, data):
    
    month = get_datetime().month
    if context.last_month == month:
        return
    context.last_month = month

    #df = get_fundamentals(
    #    query(fundamentals.valuation_ratios.ev_to_ebitda,
    #        fundamentals.valuation_ratios.sales_yield,
    #        fundamentals.operation_ratios.roic)
    #    .filter(fundamentals.company_reference.primary_exchange_id.in_(["NYSE", "NYS"]))
    #    .filter(fundamentals.operation_ratios.total_debt_equity_ratio != None)
    #    .filter(fundamentals.valuation.market_cap != None)
    #    .filter(fundamentals.valuation.shares_outstanding != None)  
    #    .filter(fundamentals.company_reference.primary_exchange_id != "OTCPK") # no pink sheets
    #    .filter(fundamentals.company_reference.primary_exchange_id != "OTCBB") # no pink sheets
    #    .filter(fundamentals.asset_classification.morningstar_sector_code != None) # require sector
    #    .filter(fundamentals.asset_classification.morningstar_sector_code != 103) # exclude financial sector
    #    .filter(fundamentals.asset_classification.morningstar_sector_code != 207) # exclude utilities sector
    #    .filter(fundamentals.share_class_reference.security_type == 'ST00000001') # common stock only
    #    .filter(~fundamentals.share_class_reference.symbol.contains('_WI')) # drop when-issued
    #    .filter(fundamentals.share_class_reference.is_primary_share == True) # remove ancillary classes
    #    .filter(((fundamentals.valuation.market_cap*1.0) / (fundamentals.valuation.shares_outstanding*1.0)) > 1.0)  # stock price > $1
    #    .filter(fundamentals.share_class_reference.is_depositary_receipt == False) # !ADR/GDR
    #    .filter(fundamentals.valuation.market_cap >= 5.0E+09)
    #    .filter(~fundamentals.company_reference.standard_name.contains(' LP')) # exclude LPs
    #    .filter(~fundamentals.company_reference.standard_name.contains(' L P'))
    #    .filter(~fundamentals.company_reference.standard_name.contains(' L.P'))
    #    .filter(fundamentals.balance_sheet.limited_partnership == None) # exclude LPs
    #    .order_by(fundamentals.valuation.market_cap.desc())
    #    .limit(500)).T
    df = pipeline_output('my_pipeline')
    df = df.dropna().sort(columns="market_cap", ascending=False).head(2000)
    
    # EV/EBITDA, in-order (lower is better), nan goes last
    #context.score += df['ev_to_ebitda'].\
    df['ev_to_ebitda_rank'] = df['ev_to_ebitda'].\
    rank(ascending = True, na_option = 'bottom')
    
    df = df.sort(columns='ev_to_ebitda_rank', ascending=True)
    df = df.head(len(df.index)*0.05)
    
    context.score = pd.Series(np.zeros(len(df.index)), index = df.index)
        
    # sales yield, inverse (higher is better), nan goes last
    context.score += df['sales_yield'].\
    rank(ascending = False, na_option = 'top')
    
    # return on invested capital, inverse (higher is better), nan goes last
    context.score += df['roic'].\
    rank(ascending = False, na_option = 'top')
    
    #context.score += df['gp'].\
    #rank(ascending = False, na_option = 'top')

    #context.score += df['pb'].\
    #rank(ascending = False, na_option = 'top')

def rebalance(context, data):

    P = data.history(context.score.index, 'price', 100, '1d')
    V = data.history(context.score.index, 'volume', 100, '1d')
    
    w = P * V
    w = w.mean()
    w = w[w > 10E+06]
    
    context.score = context.score[w.index]   
    context.longs = context.score.dropna().order().head(10).index   
    
    P = data.history(context.m, 'price', 200, '1d')
        #pos_one = (pri[security][-1])
        #pos_six = (pri[security][-75:].mean())
        #VELOCITY
        #velocity_stop = (pos_one - pos_six)/100.0
        #SPY_Velocity = velocity_stop
    if P.tail(2).median() < P.tail(200).median() or\
       P.tail(10).median() < P.tail(100).median():
        context.longs = context.bonds 

        
def buy(context,data):
    
    for s in context.portfolio.positions:
        if s in context.longs:
            continue
        if not data.can_trade(s):
            continue
        order_target(s, 0)    
    
    if get_open_orders():
        return    
    
    for s in context.longs:
        if not data.can_trade(s):
            continue
        order_value(s, context.portfolio.cash / len(context.longs))

        
def display(context,data):
    
    record(leverage = context.account.leverage,
           exposure = context.account.net_leverage)
    
                                 
def handle_data(context, data):
    
    if context.start:
        rebalance(context, data)
        buy(context, data)
        display(context, data)
        context.start = False