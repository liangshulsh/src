import numpy as np
import pandas as pd
from quantopian.pipeline import Pipeline
from quantopian.pipeline import CustomFactor
from quantopian.algorithm import attach_pipeline, pipeline_output
from quantopian.pipeline.filters import Q500US,Q3000US,Q1500US
from quantopian.pipeline.data import Fundamentals

            
def initialize(context):
    context.fast_trade = False
    set_benchmark(sid(8554))
   # schedule_function(get_prices,date_rules.every_day(), time_rules.market_open(hours=0, minutes = 1 ))
   # schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_open(hours = 0, minutes = 2))
    
    schedule_function(set_is_trading_day,date_rules.every_day(),time_rules.market_open())
    schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 16))
    schedule_function(close_, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 16))
    schedule_function(open_, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 15))
    #schedule_function(close_all, date_rules.every_day(), time_rules.market_close(hours = 0, minutes = 10))
    #schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_close(hours = 0, minutes = 31))
    #schedule_function(close_, date_rules.every_day(), time_rules.market_close(hours = 0, minutes = 31))
    #schedule_function(open_, date_rules.every_day(), time_rules.market_close(hours = 0, minutes = 30))    
    schedule_function(my_record_vars, date_rules.every_day(), time_rules.market_close())
    schedule_function(preview_position_percentage, date_rules.every_day(), time_rules.market_close(hours = 5, minutes=20))
    #schedule_function(my_record_index, date_rules.month_start(),time_rules.market_open())
   
    schedule_function(get_prices,date_rules.every_day(), time_rules.market_close(hours=5, minutes = 17))
    #schedule_function(get_prices,date_rules.every_day(), time_rules.market_close(hours=0, minutes = 32))
    if not context.fast_trade:
        schedule_function(execute_trades,date_rules.every_day(), time_rules.market_close(hours=5))
        #schedule_function(execute_trades,date_rules.every_day(), time_rules.market_close(hours=0, minutes=15))        
    
    set_commission(commission.PerShare(cost=0.005, min_trade_cost=1))
    set_slippage(slippage.FixedSlippage(spread=0.0))
    context.nq=5
    context.nq_vol=3
    context.nq_gp=3
    context.nq_pe=3
    context.nq_ps=3
    context.nq_pb=3
    context.trade_count = 3
    context.tier = 0
    context.is_trading_day = False
    #my_pipe = make_pipeline()
    #attach_pipeline(my_pipe, 'my_pipeline')
    context.max_leverage = [0]
    context.portfolio_mom_day_count = 5
    context.is_aggressive_mode = False
    context.portfolio_percent = {}
    context.SPY = [sid(8554)]
    attach_pipeline(my_pipeline(context), 'my_pipeline')
 
def set_is_trading_day(context, data):
    context.is_trading_day = True
    
def my_pipeline(context):
    """
    The original algorithm used the following filters:
        1. common stock
        2 & 3. not limited partnership - name and database check
        4. database has fundamental data
        5. not over the counter
        6. not when issued
        7. not depository receipts
        8. primary share
        9. high dollar volume
    Check Scott's notebook for more details.
    
    This updated version uses Q1500US, one of the pipeline's built-in base universes. 
    Lesson 11 from the Pipeline tutorial offers a great overview of using multiple 
    filters vs using the built-in base universes:
    https://www.quantopian.com/tutorials/pipeline#lesson11
    
    More detail on the selection criteria of this filter can be found  here:
    https://www.quantopian.com/posts/the-q500us-and-q1500us 
    """
    
    
    #is_basic_materials = Sector().eq(101)
    #is_consumer_cyclical = Sector().eq(102)
    #is_financial_services = Sector().eq(103)
    #is_real_estate = Sector().eq(104)
    #is_consumer_defensive = Sector().eq(205)
    #is_healthcare = Sector().eq(206)
    #is_utilities = Sector().eq(207)
    #is_communication_services = Sector().eq(308)
    #is_energy = Sector().eq(309)
    #is_industrials = Sector().eq(310)
    #is_technology = Sector().eq(311)
    base_universe = Q500US() #& (is_consumer_cyclical | is_technology)
    total_assets = Fundamentals.total_assets.latest
    gross_profit = Fundamentals.gross_profit.latest
    net_income = Fundamentals.net_income_income_statement.latest
    market_cap = Fundamentals.market_cap.latest
    roe = Fundamentals.roe.latest
    #ipo_date = Fundamentals.ipo_date.latest
    pe_ratio = Fundamentals.pe_ratio.latest
    pb_ratio = Fundamentals.pb_ratio.latest
    #ps_ratio = Fundamentals.ps_ratio.latest
    
    #market_cap = Fundamentals.market_cap.latest
    #roe = Fundamentals.roe.latest
    # The example algorithm - mean reversion. Note the tradable filter used as a mask.
     
    my_pipe = Pipeline(
              columns={
                'GP': gross_profit / total_assets,
                #'rel_diff': rel_diff
                #'pe': pe_ratio,
                'pb': pb_ratio,
                #'ps': ps_ratio,
                'total_assets': total_assets,
                'gross_profit': gross_profit,
                'net_income': net_income,
                #'market_cap': market_cap,
                #'ipo_date': ipo_date
                #'GM': gross_profit / market_cap
                #'roe': roe
              },
              screen = base_universe
          )
    #bottom_rel_diff = rel_diff.bottom(250)
    #my_pipe.add(bottom_rel_diff, 'bottom_rel_diff')
     
    return my_pipe
        
def before_trading_start(context, data):
    context.outputorg = pipeline_output('my_pipeline')
    context.trades = []
    context.portfolio_percent = {}
 
def preorder_target_percent(context, data, security, percentage):
    if context.fast_trade:
        order_target_percent(security, percentage)
    else:
        context.trades.append([security,percentage])    
    context.portfolio_percent[security] = percentage
 
def preview_position_percentage(context, data):
    calculate_position_percentage(context, data)
    show_position_percentage(context, data, "p")
    
def show_position_percentage(context,data, state):
    loginfo = "position_percent_" + state + "="
    total_percent = 0.0
    portfolio_keys = list(context.portfolio_percent.keys())
    portfolio_keys.sort()
    loginfolist = []
    for security in portfolio_keys:
        loginfolist.append(security.symbol + ":" + "%.4f" % (context.portfolio_percent[security]))
        total_percent = total_percent + abs(context.portfolio_percent[security])
 
    loginfo = loginfo + ",".join(loginfolist) + ",leverage=%.4f"%(total_percent)        
    #log.info(loginfo)
    
def calculate_position_percentage(context, data):
    for security in context.portfolio.positions:
        context.portfolio_percent[security] = context.portfolio.positions[security].amount * getCurrentPrice(context,data,security) / context.portfolio.portfolio_value
    
 
def getCurrentPrice(context,data,security):
    price = data.current(security, "price")
    if np.isnan(price):
        histprices = data.history([security],'price',5,'1d')
        i = 1
        while (i <= 5):
            if not np.isnan(histprices[security][-1 * i]):
                price = histprices[security][-1 * i]
                break
            i = i+1
 
    if np.isnan(price) and security in context.portfolio.positions.keys():
        price = context.portfolio.positions[security].last_sale_price
    return price
    
def get_prices(context, data):
    context.output = context.outputorg.copy()
    #short_set = set(context.output[context.output['top_rel_diff']].index)
    #long_set = set(context.output[context.output['bottom_rel_diff']].index)
    #security_set = long_set.union(short_set)
    context.output = context.output.dropna()
    security_set = context.output.index.tolist()
    Universe500=list(security_set)
    #Universe500=context.output.index.tolist()
    prices = data.history(Universe500,'price',6,'1d')
    daily_rets=np.log(prices/prices.shift(1))
    rets=(prices.iloc[-2] - prices.iloc[0]) / prices.iloc[0]
    # If you don't want to skip the most recent return, however, use .iloc[-1] instead of .iloc[-2]:
    # rets=(prices.iloc[-1] - prices.iloc[0]) / prices.iloc[0]
    stdevs=daily_rets.std(axis=0)
    rets_df=pd.DataFrame(rets,columns=['five_day_ret'])
    stdevs_df=pd.DataFrame(stdevs,columns=['stdev_ret'])
    context.output=context.output.join(rets_df,how='outer')
    context.output=context.output.join(stdevs_df,how='outer')
    context.output['ret_quantile']=pd.qcut(context.output['five_day_ret'],context.nq,labels=False)+1
    context.output['stdev_quantile']=pd.qcut(context.output['stdev_ret'],3,labels=False)+1
    context.output['gp_quantile']=pd.qcut(context.output['GP'],context.nq_gp,labels=False)+1
    context.output['ret_num']=context.output['five_day_ret'].rank(ascending=True,method='first')
    context.output['stdev_num']=context.output['stdev_ret'].rank(ascending=False,method='first')
    context.output['gp_num']=context.output['GP'].rank(ascending=True,method='first')
    #context.output['total_num']=context.output['ret_num'] + context.output['gp_num'] + context.output['stdev_num']
    #context.output['roe_quantile']=pd.qcut(context.output['roe'],context.nq_gp,labels=False)+1    
    #context.output['pe_quantile']=pd.qcut(context.output['pe'],context.nq_pe,labels=False)+1
    context.output['pb_quantile']=pd.qcut(context.output['pb'],context.nq_pb,labels=False)+1
    #context.output['ps_quantile']=pd.qcut(context.output['ps'],context.nq_ps,labels=False)+1
    #default_date=1009843200000000000L
    #context.output['start_date'] = [stock.start_date for stock in context.output.index.get_level_values(1)]
    #start_dates = context.output['start_date'].values.tolist()
    #ipo_dates=result['ipo_date'].values.tolist()
    #final_dates = []
    #for i in range(0,len(start_dates)):
    #    if start_dates[i] > default_date:
    #        final_dates.append(start_dates[i])
    #    else:
    #        final_dates.append(ipo_dates[i])
    #result['final_date'] = final_dates
    #context.output=context.output.sort(columns='rel_diff', ascending=False)
    #context.output=context.output.sort(columns='dollar_volume', ascending=True)
    #context.output=context.output.sort(columns='stdev_num', ascending=False)
    
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    pri = data.history(SPY, "price",205, "1d")
    pos = 'pri[security]'
    pos_one = (pri[SPY[0]][-1])
    pos_six = (pri[SPY[0]][-75:].mean())
    #VELOCITY
    velocity_stop = (pos_one - pos_six)/100.0
    context.SPY_Velocity = velocity_stop
    
    context.net_income_positive_stocks = context.output[(context.output['net_income'] > 0)].index.tolist()
    #context.net_income_negative_stocks = context.output[(context.output['net_income'] < 0)].index.tolist()
    if context.SPY_Velocity > 0.0:        
        context.longs=context.output[(context.output['ret_quantile']==1) &
                                (context.output['stdev_quantile']<context.nq_vol) & (context.output['gp_quantile']==context.nq_gp) & (context.output['pb_quantile']==context.nq_pb)].index.tolist() #(context.output['pb_quantile']==context.nq_pb)
        context.fulllongs=context.output[(context.output['ret_quantile']==1) & 
                                (context.output['stdev_quantile']<context.nq_vol)].index.tolist()

    else:
        context.longs=context.output[(context.output['ret_quantile']==1) &
                                (context.output['stdev_quantile']<context.nq_vol) & (context.output['gp_quantile']==context.nq_gp) & (context.output['pb_quantile']==context.nq_pb) & (context.output['net_income'] > 0)].index.tolist() #(context.output['pb_quantile']==context.nq_pb)
        context.fulllongs=context.output[(context.output['ret_quantile']==1) & 
                                (context.output['stdev_quantile']<context.nq_vol) & (context.output['net_income'] > 0)].index.tolist()
        
    #& (context.output['net_income'] > 0)
    

    #context.output=context.output.sort(columns='GP', ascending=True)
    if SPY_Velocity > 0.0:
        context.shorts= context.output[(context.output['ret_quantile']==context.nq) &
                                 (context.output['stdev_quantile']<context.nq_vol) & (context.output['gp_quantile']==1) & (context.output['pb_quantile']==context.nq_pb) & (context.output['net_income'] < 0)].index.tolist() #(context.output['pb_quantile']==context.nq_pb) & 
        context.fullshorts= context.output[(context.output['ret_quantile']==context.nq) & 
                                 (context.output['stdev_quantile']<context.nq_vol) &  (context.output['net_income'] < 0)].index.tolist()
 
    else:
        context.shorts= context.output[(context.output['ret_quantile']==context.nq) &
                                 (context.output['stdev_quantile']<context.nq_vol) & (context.output['gp_quantile']==1) & (context.output['pb_quantile']==context.nq_pb)].index.tolist() # & (context.output['pb_quantile']==context.nq_pb)
    
    #if len(context.shorts) == 0:
    #    context.shorts= context.output[(context.output['ret_quantile']==context.nq) &
    #                             (context.output['stdev_quantile']<context.nq_vol) & (context.output['gp_quantile']==1)].index.tolist()
        
        context.fullshorts= context.output[(context.output['ret_quantile']==context.nq) & 
                                 (context.output['stdev_quantile']<context.nq_vol)].index.tolist()
    
    excludeshorts = []

    #excludeshorts = ['AMT', 'ONCE']
    #context.shorts = [stock for stock in context.shorts if stock.symbol not in excludeshorts]
    #context.fullshorts = [stock for stock in context.fullshorts if stock.symbol not in excludeshorts]
    
    context.longs=context.longs[-context.trade_count:]
    context.shorts=context.shorts[:context.trade_count]
    
    #log.info("Official PnL:%s, Aggressive PnL:%s,Rate:%f, Defensive PnL:%s,Rate:%f, is_aggressive_mode:%s" % (str(context.portfolio.pnl), str(context.aggressive_portfolio.pnl), aggressive_mom_rate, str(context.defensive_portfolio.pnl), defensive_mom_rate, str(context.is_aggressive_mode)))
    
 
def execute_trades(context, data):
    if len(context.trades) > 0:
        for order in context.trades:
            order_target_percent(order[0], order[1])
            
def my_rebalance(context, data):

    #short_set = set(context.output[context.output['top_rel_diff']].index)
    #long_set = set(context.output[context.output['bottom_rel_diff']].index)
    #security_set = long_set.union(short_set)  
  
    if not context.is_trading_day:
        return
    
    calculate_position_percentage(context, data)
    
    security_set = context.output.index.tolist()
    Universe500=list(security_set)    
    #Universe500=context.output.index.tolist()
    context.existing_longs=0
    context.existing_shorts=0
    for security in context.portfolio.positions:
        if security in context.SPY:
            pass
        elif security not in Universe500 and data.can_trade(security): 
            preorder_target_percent(context,data, security, 0)
        else:
            if data.can_trade(security):
                current_quantile=context.output['ret_quantile'].loc[security]
                if context.portfolio.positions[security].amount>0:
                    if context.SPY_Velocity < 0 and security not in context.net_income_positive_stocks:
                        preorder_target_percent(context, data, security, 0)
                    elif (current_quantile==1) and (security not in context.longs):
                        context.existing_longs += 1
                    elif (current_quantile>1) and (security not in context.fullshorts):
                        preorder_target_percent(context, data, security, 0)
                elif context.portfolio.positions[security].amount<0:
                    if context.SPY_Velocity > 0: # and security not in context.net_income_negative_stocks:
                        preorder_target_percent(context, data, security, 0)
                    elif (current_quantile==context.nq) and (security not in context.shorts):
                        context.existing_shorts += 1
                    elif (current_quantile<context.nq) and (security not in context.fulllongs):
                        preorder_target_percent(context, data, security, 0)
             
    show_position_percentage(context, data, "r")
                        
def close_(context, data):
    
    if not context.is_trading_day:
        return
    #exchange_time = get_datetime('US/Eastern')
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",205, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.0
            short_leverage = -0.0
        else:
            long_leverage = 1.0
            short_leverage = -0.7
        for security in context.shorts:
            if data.can_trade(security):
                preorder_target_percent(context, data, security, short_leverage/(len(context.shorts)+context.existing_shorts))
     
    show_position_percentage(context, data, "c")
             
def open_(context, data):
   
    if not context.is_trading_day:
        return
    
    exchange_time = get_datetime('US/Eastern')
    
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",205, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.0
            short_leverage = -0.0
        else:
            long_leverage = 1.0
            short_leverage = -0.7
    for security in context.longs:
        if data.can_trade(security):
            preorder_target_percent(context, data, security, long_leverage/(len(context.longs)+context.existing_longs))
 
    show_position_percentage(context, data, "o")

def close_all(context, data):
    for security in context.portfolio.positions:
        order_target_percent(security, 0)
        
def my_record_index(context, data):
    record(MemeberCount = len(context.outputorg.index))
    index_members = np.reshape([s.symbol for s in context.outputorg.index.tolist()],(5,100))
    for members in index_members:
        log.info(",".join([s for s in members]))
    
def my_record_vars(context, data):
    context.is_trading_day = False
    longs = shorts = 0
    
    for position in context.portfolio.positions.values():
        if position.amount > 0:
            longs += 1
        elif position.amount < 0:
            shorts += 1
    leverage = context.account.leverage
    for num in context.max_leverage:
        if leverage > num:
            context.max_leverage.remove(num)
            context.max_leverage.append(leverage)
    record(Max_Leverage = context.max_leverage[-1])
    record(leverage=context.account.leverage, long_count=longs, short_count=shorts) 
    #log.info("Today's shorts: "  +", ".join([short_.symbol for short_ in context.shorts]))
    #log.info("Today's longs: "  +", ".join([long_.symbol for long_ in context.longs]))
    #log.info("Cumulative PnL:" + str(context.portfolio.pnl))