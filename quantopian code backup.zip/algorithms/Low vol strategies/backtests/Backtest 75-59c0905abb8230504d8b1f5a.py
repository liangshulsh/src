import numpy as np
import pandas as pd
from quantopian.pipeline import Pipeline
from quantopian.pipeline import CustomFactor
from quantopian.algorithm import attach_pipeline, pipeline_output
from quantopian.pipeline.data.builtin import USEquityPricing
from quantopian.pipeline.factors import SimpleMovingAverage, AverageDollarVolume
from quantopian.pipeline.data import morningstar
from quantopian.pipeline.filters import Q500US,Q3000US

def initialize(context):
    set_benchmark(sid(8554))
    schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 1))
    schedule_function(close_, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 1))
    schedule_function(open_, date_rules.every_day(), time_rules.market_close(hours = 5))
    schedule_function(my_record_vars, date_rules.every_day(), time_rules.market_close())
    schedule_function(get_prices,date_rules.every_day(), time_rules.market_close(hours=5, minutes = 2 ))
    set_commission(commission.PerShare(cost=0.005, min_trade_cost=1))
    set_slippage(slippage.FixedSlippage(spread=0))
    context.nq=5
    context.nq_vol=3
    context.trade_count =3
    my_pipe = make_pipeline()
    attach_pipeline(my_pipe, 'my_pipeline')
    context.max_leverage = [0]

class Volatility(CustomFactor):  
    inputs = [USEquityPricing.close]
    window_length=132
    
    def compute(self, today, assets, out, close):

        daily_returns = np.log(close[1:-6]) - np.log(close[0:-7])
        out[:] = daily_returns.std(axis = 0)           

class Liquidity(CustomFactor):   
    inputs = [USEquityPricing.volume, morningstar.valuation.shares_outstanding] 
    window_length = 1
    
    def compute(self, today, assets, out, volume, shares):       
        out[:] = volume[-1]/shares[-1]        
        
class Sector(CustomFactor):
    inputs=[morningstar.asset_classification.morningstar_sector_code]
    window_length=1
    
    def compute(self, today, assets, out, sector):
        out[:] = sector[-1]   
        
        
def make_pipeline():
    pricing=USEquityPricing.close.latest

    # vol=Volatility(mask=Q500US())
    # sector=morningstar.asset_classification.morningstar_sector_code.latest
    # vol=vol.zscore(groupby=sector)
    # vol_filter=vol.percentile_between(0,100)

    # liquidity=Liquidity(mask=Q500US())
    # liquidity_filter=liquidity.percentile_between(0,75) | liquidity.isnan()
    
    universe = (
        Q500US()
        # & liquidity_filter
        # & volatility_filter
    )


    return Pipeline(
        screen=universe)
def before_trading_start(context, data):
    context.output = pipeline_output('my_pipeline')
   
def get_prices(context, data):
    Universe500=context.output.index.tolist()
    prices = data.history(Universe500,'price',6,'1d')
    daily_rets=np.log(prices/prices.shift(1))
    rets=(prices.iloc[-2] - prices.iloc[0]) / prices.iloc[0]
    # If you don't want to skip the most recent return, however, use .iloc[-1] instead of .iloc[-2]:
    # rets=(prices.iloc[-1] - prices.iloc[0]) / prices.iloc[0]
    stdevs=daily_rets.std(axis=0)
    rets_df=pd.DataFrame(rets,columns=['five_day_ret'])
    stdevs_df=pd.DataFrame(stdevs,columns=['stdev_ret'])
    context.output=context.output.join(rets_df,how='outer')
    context.output=context.output.join(stdevs_df,how='outer')    
    context.output['ret_quantile']=pd.qcut(context.output['five_day_ret'],context.nq,labels=False)+1
    context.output['stdev_quantile']=pd.qcut(context.output['stdev_ret'],3,labels=False)+1
    context.output.sort(columns='five_day_ret', ascending=True)
    context.longs=context.output[(context.output['ret_quantile']==1) & 
                                (context.output['stdev_quantile']<context.nq_vol)].index.tolist()       
    context.shorts=context.output[(context.output['ret_quantile']==context.nq) & 
                                 (context.output['stdev_quantile']<context.nq_vol)].index.tolist()    
    context.fulllongs=context.longs
    context.fullshorts=context.shorts
    if context.trade_count > 0:
        context.longs = context.longs[-context.trade_count:] + context.longs[:context.trade_count]
        context.shorts = context.shorts[-context.trade_count:] + context.shorts[:context.trade_count]

def my_rebalance(context, data):
    Universe500=context.output.index.tolist()
    context.existing_longs=0
    context.existing_shorts=0
    for security in context.portfolio.positions:
        if security not in Universe500 and data.can_trade(security): 
            order_target_percent(security, 0)
        else:
            if data.can_trade(security):
                current_quantile=context.output['ret_quantile'].loc[security]
                if context.portfolio.positions[security].amount>0:
                    if (current_quantile==1) and (security not in context.longs):
                        context.existing_longs += 1
                    elif (current_quantile>1) and (security not in context.fullshorts):
                        order_target_percent(security, 0)
                elif context.portfolio.positions[security].amount<0:
                    if (current_quantile==context.nq) and (security not in context.shorts):
                        context.existing_shorts += 1
                    elif (current_quantile<context.nq) and (security not in context.fulllongs):
                        order_target_percent(security, 0)
def close_(context, data):
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",200, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.8
            short_leverage = -0.0
        else:
            long_leverage = 1.1
            short_leverage = -0.7
        for security in context.shorts:
            if data.can_trade(security):
                order_target_percent(security, short_leverage/(len(context.shorts)+context.existing_shorts))
def open_(context, data):
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",200, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.8
            short_leverage = -0.0
        else:
            long_leverage = 1.1
            short_leverage = -0.7
    for security in context.longs:
        if data.can_trade(security):
            order_target_percent(security, long_leverage/(len(context.longs)+context.existing_longs))
def my_record_vars(context, data):
    longs = shorts = 0
    for position in context.portfolio.positions.itervalues():
        if position.amount > 0:
            longs += 1
        elif position.amount < 0:
            shorts += 1
    leverage = context.account.leverage
    for num in context.max_leverage:
        if leverage > num:
            context.max_leverage.remove(num)
            context.max_leverage.append(leverage)
    record(Max_Leverage = context.max_leverage[-1])
    record(leverage=context.account.leverage, long_count=longs, short_count=shorts) 
    log.info("Today's shorts: "  +", ".join([short_.symbol for short_ in context.shorts]))
    log.info("Today's longs: "  +", ".join([long_.symbol for long_ in context.longs]))