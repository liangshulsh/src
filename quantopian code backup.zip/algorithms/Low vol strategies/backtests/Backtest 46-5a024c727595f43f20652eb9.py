import numpy as np
import pandas as pd
from quantopian.pipeline import Pipeline
from quantopian.pipeline import CustomFactor
from quantopian.algorithm import attach_pipeline, pipeline_output
from quantopian.pipeline.data.builtin import USEquityPricing
from quantopian.pipeline.factors import SimpleMovingAverage, AverageDollarVolume
from quantopian.pipeline.data import morningstar
from quantopian.pipeline.filters import Q500US,Q3000US,Q1500US

class CapitalManager:
    initcapital = 10000
    capital = 10000
    cash = 0
    pnl = 0
    portfolio_value = 0
    positions = {}
    positions_value = {}
    cost = 0.005
    min_trade_cost=1
    leverage = 0
    portfolioRecords=[]
    
    def init(self, initcapital=10000, cost=0.005, min_trade_cost=1):
        self.initcapital = initcapital
        self.capital = initcapital
        self.capital_used = 0
        self.cash = self.capital
        self.pnl = 0
        self.portfolio_value = 0
        self.positions = {}
        self.positions_value = {}
        self.cost = 0.005
        self.min_trade_cost = 1
        self.leverage = 0
        
    def recordPortfolioValue(self,data):
        self.updatePortfolioValues(data)
        self.portfolioRecords.append((get_datetime("US/Eastern"),self.capital))
        
    def getCurrentPrice(self,data,security):
        price = data.current(security, "price")
        if np.isnan(price):
            histprices = data.history([security],'price',5,'1d')
            i = 1
            while (i <= 5):
                if not np.isnan(histprices[security][-1 * i]):
                    price = histprices[security][-1 * i]
                    break
                i = i+1
                
        if np.isnan(price) and security in self.positions.keys():
            price = self.positions[security][1]
        return price
    
    def updatePortfolioValues(self,data):
        totalvalue = 0
        self.positions_value = {}
        for position, value in self.positions.items():
            posvalue = value[0] * self.getCurrentPrice(data, position)
            self.positions_value[position] = posvalue
            totalvalue = totalvalue + posvalue
        capital = totalvalue + self.cash
        portfolio_value = totalvalue
        pnl = capital - self.initcapital
        leverage = portfolio_value / capital
        self.capital = capital
        self.pnl = pnl
        self.portfolio_value = portfolio_value
        self.leverage = leverage
        
        if np.isnan(capital) or np.isnan(pnl):
            for position, value in self.positions.items():
                log.info("%s:%f,%f" % (position, value[0], self.getCurrentPrice(data, position)))

    def porder_target_percent(self,data, security, perc):
        curprice = self.getCurrentPrice(data, security)
        try:
            if not np.isnan(curprice):
                quantity = int(round(self.capital * perc / curprice))
                position = [0,0]
                if (security in self.positions.keys()):
                    position = self.positions[security]
                else:
                    self.positions[security] = position
            
                quantitychange = quantity - position[0]
                self.positions[security][0] = quantity
                self.positions[security][1] = curprice
                if (quantity == 0):
                    del self.positions[security]
                cost = abs(quantitychange) * self.cost
                if (cost < self.min_trade_cost):
                    cost = self.min_trade_cost
                self.cash = self.cash - quantitychange * curprice - cost
                self.updatePortfolioValues(data)
        except:
            log.info("porder error: curprice is %f, capital is %f, perc is %f" % (curprice, self.capital, perc))
    
def initialize(context):
    context.fast_trade = True
    set_benchmark(sid(8554))
   # schedule_function(get_prices,date_rules.every_day(), time_rules.market_open(hours=0, minutes = 1 ))
   # schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_open(hours = 0, minutes = 2))
    context.portfolio_manager = CapitalManager()
    context.portfolio_manager.init()
    
    schedule_function(my_rebalance, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 1))
    schedule_function(close_, date_rules.every_day(), time_rules.market_close(hours = 5, minutes = 1))
    schedule_function(open_, date_rules.every_day(), time_rules.market_close(hours = 5))
    schedule_function(my_record_vars, date_rules.every_day(), time_rules.market_close())
    
    #schedule_function(my_record_index, date_rules.month_start(),time_rules.market_open())
    
    schedule_function(get_prices,date_rules.every_day(), time_rules.market_close(hours=5, minutes = 2 ))
    if not context.fast_trade:
    	schedule_function(execute_trades,date_rules.every_day(), time_rules.market_close(hours=4, minutes = 45))
    
    set_commission(commission.PerShare(cost=0.005, min_trade_cost=1))
    set_slippage(slippage.FixedSlippage(spread=0.0))
    context.nq=5
    context.nq_vol=3
    context.trade_count =3
    #my_pipe = make_pipeline()
    #attach_pipeline(my_pipe, 'my_pipeline')
    context.max_leverage = [0]

    attach_pipeline(my_pipeline(context), 'my_pipeline')

def my_pipeline(context):
    my_pipe = Pipeline()
    """
    The original algorithm used the following filters:
        1. common stock
        2 & 3. not limited partnership - name and database check
        4. database has fundamental data
        5. not over the counter
        6. not when issued
        7. not depository receipts
        8. primary share
        9. high dollar volume
    Check Scott's notebook for more details.
    
    This updated version uses Q1500US, one of the pipeline's built-in base universes. 
    Lesson 11 from the Pipeline tutorial offers a great overview of using multiple 
    filters vs using the built-in base universes:
    https://www.quantopian.com/tutorials/pipeline#lesson11
    
    More detail on the selection criteria of this filter can be found  here:
    https://www.quantopian.com/posts/the-q500us-and-q1500us 
    """
    base_universe = Q500US()
    
    # The example algorithm - mean reversion. Note the tradable filter used as a mask.
    sma_10 = SimpleMovingAverage(inputs=[USEquityPricing.close], window_length=10,
                                 mask=base_universe)
    sma_30 = SimpleMovingAverage(inputs=[USEquityPricing.close], window_length=30,
                                 mask=base_universe)
    rel_diff = (sma_10 - sma_30) / sma_30
    
    top_rel_diff = rel_diff.top(500)
    my_pipe.add(top_rel_diff, 'top_rel_diff')
    #bottom_rel_diff = rel_diff.bottom(250)
    #my_pipe.add(bottom_rel_diff, 'bottom_rel_diff')
     
    return my_pipe

class Volatility(CustomFactor):  
    inputs = [USEquityPricing.close]
    window_length=132
    
    def compute(self, today, assets, out, close):

        daily_returns = np.log(close[1:-6]) - np.log(close[0:-7])
        out[:] = daily_returns.std(axis = 0)           

class Liquidity(CustomFactor):   
    inputs = [USEquityPricing.volume, morningstar.valuation.shares_outstanding] 
    window_length = 1
    
    def compute(self, today, assets, out, volume, shares):       
        out[:] = volume[-1]/shares[-1]        
        
class Sector(CustomFactor):
    inputs=[morningstar.asset_classification.morningstar_sector_code]
    window_length=1
    
    def compute(self, today, assets, out, sector):
        out[:] = sector[-1]   
        
        
def make_pipeline():
    pricing=USEquityPricing.close.latest

    # vol=Volatility(mask=Q500US())
    # sector=morningstar.asset_classification.morningstar_sector_code.latest
    # vol=vol.zscore(groupby=sector)
    # vol_filter=vol.percentile_between(0,100)

    # liquidity=Liquidity(mask=Q500US())
    # liquidity_filter=liquidity.percentile_between(0,75) | liquidity.isnan()
    
    universe = (
        Q500US()
        # & liquidity_filter
        # & volatility_filter
    )


    return Pipeline(
        screen=universe)
def before_trading_start(context, data):
    context.outputorg = pipeline_output('my_pipeline')
    context.trades = []

def preorder_target_percent(context, data, security, percentage):
    context.portfolio_manager.porder_target_percent(data, security, percentage)
    if context.fast_trade:
        order_target_percent(security, percentage)
    else:
    	context.trades.append([security,percentage])
    
def get_prices(context, data):
    context.output = context.outputorg.copy()
    #short_set = set(context.output[context.output['top_rel_diff']].index)
    #long_set = set(context.output[context.output['bottom_rel_diff']].index)
    #security_set = long_set.union(short_set)    
    security_set = context.output[context.output['top_rel_diff']].index.tolist()
    Universe500=list(security_set)
    #Universe500=context.output.index.tolist()
    prices = data.history(Universe500,'price',6,'1d')
    daily_rets=np.log(prices/prices.shift(1))
    rets=(prices.iloc[-2] - prices.iloc[0]) / prices.iloc[0]
    # If you don't want to skip the most recent return, however, use .iloc[-1] instead of .iloc[-2]:
    # rets=(prices.iloc[-1] - prices.iloc[0]) / prices.iloc[0]
    stdevs=daily_rets.std(axis=0)
    rets_df=pd.DataFrame(rets,columns=['five_day_ret'])
    stdevs_df=pd.DataFrame(stdevs,columns=['stdev_ret'])
    context.output=context.output.join(rets_df,how='outer')
    context.output=context.output.join(stdevs_df,how='outer')    
    context.output['ret_quantile']=pd.qcut(context.output['five_day_ret'],context.nq,labels=False)+1
    context.output['stdev_quantile']=pd.qcut(context.output['stdev_ret'],3,labels=False)+1
    context.output.sort(columns='five_day_ret', ascending=True)
    context.longs=context.output[(context.output['ret_quantile']==1) & 
                                (context.output['stdev_quantile']<context.nq_vol)].index.tolist()       
    context.shorts=context.output[(context.output['ret_quantile']==context.nq) & 
                                 (context.output['stdev_quantile']<context.nq_vol)].index.tolist()    
    context.fulllongs=context.longs
    context.fullshorts=context.shorts
    if context.trade_count > 0:
        context.longs = context.longs[:context.trade_count]
        context.shorts = context.shorts[-context.trade_count:]
    context.portfolio_manager.updatePortfolioValues(data)
    log.info("Official PnL:%s, Simulation PnL:%s" % (str(context.portfolio.pnl), str(context.portfolio_manager.pnl))) 

def execute_trades(context, data):
    if len(context.trades) > 0:
        for order in context.trades:
            order_target_percent(order[0], order[1])
            
def my_rebalance(context, data):
    #short_set = set(context.output[context.output['top_rel_diff']].index)
    #long_set = set(context.output[context.output['bottom_rel_diff']].index)
    #security_set = long_set.union(short_set)    
    security_set = context.output[context.output['top_rel_diff']].index.tolist()
    Universe500=list(security_set)    
    #Universe500=context.output.index.tolist()
    context.existing_longs=0
    context.existing_shorts=0
    for security in context.portfolio.positions:
        if security not in Universe500 and data.can_trade(security): 
            preorder_target_percent(context,data, security, 0)
        else:
            if data.can_trade(security):
                current_quantile=context.output['ret_quantile'].loc[security]
                if context.portfolio.positions[security].amount>0:
                    if (current_quantile==1) and (security not in context.longs):
                        context.existing_longs += 1
                    elif (current_quantile>1) and (security not in context.fullshorts):
                        preorder_target_percent(context, data, security, 0)
                elif context.portfolio.positions[security].amount<0:
                    if (current_quantile==context.nq) and (security not in context.shorts):
                        context.existing_shorts += 1
                    elif (current_quantile<context.nq) and (security not in context.fulllongs):
                        preorder_target_percent(context, data, security, 0)
                        
def close_(context, data):
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",205, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.8
            short_leverage = -0.0
        else:
            long_leverage = 1.1
            short_leverage = -0.7
        for security in context.shorts:
            if data.can_trade(security):
                preorder_target_percent(context, data, security, short_leverage/(len(context.shorts)+context.existing_shorts))
                
def open_(context, data):
    SPY = [sid(8554)]
    SPY_Velocity = 0
    long_leverage = 0
    short_leverage = 0
    for security in SPY:
        pri = data.history(SPY, "price",205, "1d")
        pos = 'pri[security]'
        pos_one = (pri[security][-1])
        pos_six = (pri[security][-75:].mean())
        #VELOCITY
        velocity_stop = (pos_one - pos_six)/100.0
        SPY_Velocity = velocity_stop
        if SPY_Velocity > 0.0:
            long_leverage = 1.8
            short_leverage = -0.0
        else:
            long_leverage = 1.1
            short_leverage = -0.7
    for security in context.longs:
        if data.can_trade(security):
            preorder_target_percent(context, data, security, long_leverage/(len(context.longs)+context.existing_longs))

def my_record_index(context, data):
    record(MemeberCount = len(context.outputorg.index))
    index_members = np.reshape([s.symbol for s in context.outputorg.index.tolist()],(5,100))
    for members in index_members:
		log.info(",".join([s for s in members]))
    
def my_record_vars(context, data):
    longs = shorts = 0
    
    for position in context.portfolio.positions.itervalues():
        if position.amount > 0:
            longs += 1
        elif position.amount < 0:
            shorts += 1
    leverage = context.account.leverage
    for num in context.max_leverage:
        if leverage > num:
            context.max_leverage.remove(num)
            context.max_leverage.append(leverage)
    record(Max_Leverage = context.max_leverage[-1])
    record(leverage=context.account.leverage, long_count=longs, short_count=shorts) 
    #log.info("Today's shorts: "  +", ".join([short_.symbol for short_ in context.shorts]))
    #log.info("Today's longs: "  +", ".join([long_.symbol for long_ in context.longs]))
    #log.info("Cumulative PnL:" + str(context.portfolio.pnl))
