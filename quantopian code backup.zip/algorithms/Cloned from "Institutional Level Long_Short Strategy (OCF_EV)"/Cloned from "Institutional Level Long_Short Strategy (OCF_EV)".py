"""
This is a template algorithm on Quantopian for you to adapt and fill in.
"""
import pandas as pd
import numpy as np
from quantopian.algorithm import attach_pipeline, pipeline_output
from quantopian.pipeline import Pipeline
from quantopian.pipeline.filters.morningstar import IsPrimaryShare
from quantopian.pipeline.data.builtin import USEquityPricing
from quantopian.pipeline.factors import AverageDollarVolume, CustomFactor
from quantopian.pipeline.classifiers.morningstar import Sector
from quantopian.pipeline.data import morningstar as mstar

# ============================================================== #  
def initialize(context):
    """
    Called once at the start of the algorithm.
    """   
    
    set_commission(commission.PerShare(cost=.0035, min_trade_cost=0.0))
    set_slippage(slippage.VolumeShareSlippage(volume_limit=.10, price_impact=0.0005)) 

    # SPY is inappropriate benchmark for market neutral strategy
    # Is ok for backtest purposes
    context.benchmark = symbol('SPY')

    # initialize persistent labels for list of stocks
    context.longs = None
    context.shorts = None
    context.same_longs = None
    context.same_shorts = None
    
    # portfolio target leverage
    context.target_leverage = 1.
    
    # rebalance corridor width set equal to +/- 5%
    context.rebalance_threshold = .05 
    
    # number of bins for factor quantiles
    context.bins_ = 5
    
    # persistent df object with index:symbols and columns:sector, value
    # useful for querying when class. info is necessary such as sector neutral
    context.pipe_output = None
    context.sector_weights = None
    
    # persistent dataframe containing weights, sector info
    context.target_long = None
    context.target_short = None
    
    # empty dict for order tracking function
    context.orders = {}      

    schedule_function(HandleEntry,
                      date_rule=date_rules.month_start(), 
                      time_rule=time_rules.market_open(minutes=30))
 
    schedule_function(Target_Portfolio_Rebalance, 
                      date_rule=date_rules.week_end(), 
                      time_rule=time_rules.market_open(minutes=35))    
    
    schedule_function(record_vars,
                      date_rule=date_rules.every_day(),
                      time_rule=time_rules.market_close(minutes=5))     

    schedule_function(track_orders_2,
                      date_rule=date_rules.every_day(),
                      time_rule=time_rules.market_close(minutes=10))  
        
    attach_pipeline(my_pipeline(context), 'my_pipeline')  
        
# ============================================================== #
def my_pipeline(context):
    pipe = Pipeline()
    
    # must be a US based stock.
    country_ref = mstar.company_reference.country_id.latest.eq('USA')
    
    # Must have market cap data
    have_data = mstar.valuation.market_cap.latest.notnull()
    
    # Equities for which morningstar's most recent Market Cap value is above $30m.    
    mkt_cap_thresh = (mstar.valuation.market_cap.latest > 30e6)
    
    # Not Misc. sector:
    sector_check = Sector().notnull()    
    
    # Limit exchanges to Nasdaq and NYS
    xch = (mstar.company_reference.primary_exchange_id.latest.eq('NAS') or \
           mstar.company_reference.primary_exchange_id.latest.eq('NYS'))
    
    # Equities that listed as common stock (as opposed to, say, preferred stock).
    # This is our first string column. The .eq method used here produces a Filter returning
    # True for all asset/date pairs where security_type produced a value of 'ST00000001'.    
    common_stock = mstar.share_class_reference.security_type.latest.eq('ST00000001')
    
    # Equities whose company name ends with 'LP' or a similar string.
    # The .matches() method uses the standard library `re` module to match
    # against a regular expression.    
    not_lp_name = ~mstar.company_reference.standard_name.latest.matches('.* L[\\. ]?P\.?$')
    
    # Equities with a null entry for the balance_sheet.limited_partnership field.
    # This is an alternative way of checking for LPs.    
    not_lp_balance_sheet = mstar.balance_sheet.limited_partnership.latest.isnull()


    # Equities whose exchange id does not start with OTC (Over The Counter).
    # startswith() is a new method available only on string-dtype Classifiers.
    # It returns a Filter.    
    not_otc = ~mstar.share_class_reference.exchange_id.latest.startswith('OTC')
    
    # Equities whose symbol (according to morningstar) ends with .WI
    # This generally indicates a "When Issued" offering.
    # endswith() works similarly to startswith().    
    not_wi = ~mstar.share_class_reference.symbol.latest.endswith('.WI')
    
    # Equities not listed as depositary receipts by morningstar.
    # Note the inversion operator, `~`, at the start of the expression.    
    not_depository = ~mstar.share_class_reference.is_depositary_receipt.latest
    
    # Equities that morningstar lists as primary shares.
    # NOTE: This will return False for stocks not in the morningstar database.    
    primary_share = IsPrimaryShare()
    
    # initialize filter/mask
    tradable_filter = (country_ref & mkt_cap_thresh & sector_check & xch &
                       common_stock & not_lp_name & not_lp_balance_sheet &
                       have_data & not_otc & not_wi & not_depository & primary_share) 
    
    # take top 60% of stocks by ADV
    high_volume_tradable = (AverageDollarVolume(window_length=21,
                                                mask=tradable_filter).percentile_between(40, 100)) 
  
    # initialize and add "value" factor to pipeline
    value = Value()    
    pipe.add(value, "value")
    
    # initialize and add "sector" factor to pipeline    
    sector = Sector()
    pipe.add(sector, 'sector')
    
    # add screen/filters to pipeline
    pipe.set_screen(high_volume_tradable)
    return pipe
# ============================================================== #    
# Custom Factor Logic
# ============================================================== #
class Value(CustomFactor):
    # value factor based on OCF/EV    
    inputs = [mstar.cash_flow_statement.operating_cash_flow,
              mstar.valuation.enterprise_value] 
    window_length = 1
  
    def compute(self, today, assets, out, ocf, ev):
        factor_df = pd.DataFrame(index=assets)
        factor_df["ocf"] = ocf[-1]
        factor_df["ev"] = ev[-1]
        out[:] = (factor_df['ocf'] / factor_df['ev'])
    
# ============================================================== #    
# Before Trading Start Logic
# ============================================================== #   
def before_trading_start(context, data):
    """
    Called every day before market open.
    """
    c = context
    c.output = pipeline_output('my_pipeline')
    output = c.output
    # _________________________________________________________ #        
    # drop any stocks with -1 label and any NANs
    syms = output[output['sector'] != -1].dropna().head(3000)
    syms.index.name = 'symbols'
    c.pipe_output = syms
    # _________________________________________________________ #        
    # Sector Neutral logic
    
    sector_counts = syms.groupby('sector').size()
    # we want at least min N stocks per group
    sectors = [Sec for Sec in sector_counts.index if sector_counts[Sec] > 5] 
    print('> N sectors w/ gt M stocks: {}'.format(len(sectors)))
    
    # filter our dataframe to include only the sectors meeting our size requirement
    # note the use of pandas' query function to easily filter the df    
    f1 = syms.query('sector == @sectors') 
    
    # calculate sector weights on filtered dataframe
    c.sector_weights = f1.groupby('sector').size() / f1.groupby('sector').size().sum()    
   
    def get_quantiles(c, factor_arr, sector_code):
        """
        Function to calculate factor quantiles for a single sector using sector code
        
        Inputs
        ------
        c: context
        factor_df: pd.DataFrame() containing stocks in index, sector codes and factor values
        sector_code: int() mstar sector code
        
        Returns
        -------
        TopQ: list of stocks in the top quantile bin
        BotQ: list of stocks in the bottom quantile bin
        """        
        f = factor_arr.query('sector==@sector_code')['value']
        factorQ = pd.qcut(f, c.bins_, labels=False)
        BotQ = factorQ[factorQ == 0] # smallest factor value bin
        TopQ = factorQ[factorQ == (c.bins_ - 1)] # largest factor value bin
        print('Sector: {} | TopQ N: {} | BotQ N: {}'.format(sector_code, len(TopQ), len(BotQ)))
        return list(TopQ.index), list(BotQ.index)

    # These are the securities that we are interested in trading each interval
    # This loops through each sector code returning the top/bottom stocks in each sector    
    ls, ss = [], []
    for sect in sectors:
        top, bot = get_quantiles(c, f1, sect)
        ls += top
        ss += bot
    # _________________________________________________________ #            
    # assign our local stock lists to the global lists 
 
    c.longs = ls
    c.shorts = ss
# ============================================================== #    
# Handle Entry Logic
# ============================================================== # 
def HandleEntry(context, data):
    """
    Execute orders according to our schedule_function() timing. 
    """
    c = context; Pos = c.portfolio.positions
    
    # Tradeable Secs
    Longs = c.longs 
    Shorts = c.shorts
    
    # _________________________________________________________ #    
    # Open position mgmt
    
    # identify stocks that are both currently owned and in target portfolio
    OpenPos = [sym for sym in Pos if Pos[sym].amount != 0] 
    
    # list of stocks meeting both criteria
    c.same_longs = [sym for sym in OpenPos if sym in Longs]
    c.same_shorts = [sym for sym in OpenPos if sym in Shorts]

    # list of open positions that are 
    OpenPosLongs = [sym for sym in Pos if Pos[sym].amount > 0 and sym in c.same_longs]
    OpenPosShorts = [sym for sym in Pos if Pos[sym].amount < 0 and sym in c.same_shorts]
    # ----- 

    Longs += OpenPosLongs 
    Shorts += OpenPosShorts
    
    Longs = set(Longs)
    Shorts = set(Shorts)
    N_Eligible = float(sum( [len(Longs), len(Shorts)] ))
    print('Eligible: %.2f' % N_Eligible)
    
    # ----------
    # Sector Weight Logic
    # ----------    
    def within_sector_weights(list_of_tuples):
        """
        Convenience function to calc portfolio weights for each stock
        """
        cols = ['symbols', 'sectors', 'sector_grp_weight']
        df = pd.DataFrame(list_of_tuples, columns=cols)
        
        port_sym_wts = []

        for sector in df['sectors'].unique():
            sect_query = df.query('sectors==@sector')
            for sym in sect_query['symbols']:
                weight_in_sector = 1./len(sect_query.index)
                sector_group_wt = sect_query['sector_grp_weight'].unique()[0] # 
                # symbol | symbol weight in portfolio
                port_sym_wts.append((sym, weight_in_sector * sector_group_wt))
        return port_sym_wts    
    # _________________________________________________________ #     
    # calculate each stocks' port weight given sector weighting     

    # persistent list of tuples containing weights, sector info
    c.target_long = None
    c.target_short = None 
    
    # ----------------  
    # Long Weights
    # ----------------            
    long_tups_list = []
    for S in Longs:
        if S in c.pipe_output.index:
            sect = c.pipe_output.loc[S, 'sector']
            tmp_tup = (S, sect, c.sector_weights.loc[sect])
            long_tups_list.append(tmp_tup)
        else: continue
    # ----------------
    c.target_long = within_sector_weights(long_tups_list) 
    
    # ----------------  
    # Short Weights
    # ----------------          
    short_sector_weights = c.sector_weights * -1        
    short_tups_list = []
    for S in Shorts:
        if S in c.pipe_output.index:
            sect = c.pipe_output.loc[S, 'sector']
            tmp_tup = (S, sect, short_sector_weights.loc[sect])
            short_tups_list.append(tmp_tup)
        else: continue
    # ----------------
    c.target_short = within_sector_weights(short_tups_list)          

    # _________________________________________________________ #    
    # send order using weights and leverage    
    long_errors = []
    for ltup in c.target_long:
        S = ltup[0] # stock symbol
        if data.can_trade(S):
            try:
                stock_wt = ltup[1]
                order_target_percent(S, stock_wt * c.target_leverage)
                print('> Long:  sid: {} | Timestamp: {}'.format(S.symbol, get_datetime()))
            except: long_errors.append((S.symbol, get_datetime()))
    # _________________________________________________________ #    
    short_errors = []                                      
    for stup in c.target_short:
        S = stup[0] # stock symbol
        if data.can_trade(S):
            try:      
                stock_wt = stup[1]
                order_target_percent(S, stock_wt * c.target_leverage)
                print('> Short:  sid: {} | Timestamp: {}'.format(S.symbol, get_datetime()))
            except: short_errors.append((S.symbol, get_datetime()))
# ============================================================== #    
# Rebalance Code Based on Target Portfolio
# ============================================================== #
def Target_Portfolio_Rebalance(context, data):
    c = context; Pos = c.portfolio.positions; PortV = c.portfolio.portfolio_value
    # _________________________________________________________ #      
    # list of open positions
    OpenPos = [sym for sym in Pos if Pos[sym].amount != 0]
    OpenPosLongs = [sym for sym in Pos if Pos[sym].amount > 0]
    OpenPosShorts = [sym for sym in Pos if Pos[sym].amount < 0]
    # _________________________________________________________ #    
    # Sector Neutral Weight logic   
    if c.target_long is None:
        return
    
    cols = ['symbols', 'weights']
    df_tgt_wts_L = pd.DataFrame(c.target_long, columns=cols)
    max_thresh_L = df_tgt_wts_L['weights'] + df_tgt_wts_L['weights']*c.rebalance_threshold
    min_thresh_L = df_tgt_wts_L['weights'] - df_tgt_wts_L['weights']*c.rebalance_threshold
    
    df_tgt_wts_S = pd.DataFrame(c.target_short, columns=cols)
    max_thresh_S = df_tgt_wts_S['weights'] + df_tgt_wts_S['weights']*c.rebalance_threshold
    min_thresh_S = df_tgt_wts_S['weights'] - df_tgt_wts_S['weights']*c.rebalance_threshold   

    # _________________________________________________________ #      
    # Anonymous Get Current Allocation Function
    CurWt = lambda x: (Pos[x].amount * Pos[x].last_sale_price) / PortV
    CurWtLong = pd.Series([CurWt(x) for x in OpenPosLongs], index=OpenPosLongs)
    CurWtShort = pd.Series([CurWt(x) for x in OpenPosShorts], index=OpenPosShorts)
    log.info(" > CurWtLong\n{}".format(CurWtLong))
    log.info(" > CurWtShort\n{}".format(CurWtShort))     
    # _________________________________________________________ #  
    # rebalance to target longs
    long_errors = []
    def check_target_longs(context, data):
        """
        Function to test each stock's weight against the rebalance corridor. 
        If any stocks fall outside the band, send orders to rebalance the long portfolio
        """        
        log.info("Target Weights LONGS: LevtgtWT={} | minus={} | plus={}".
              format(df_tgt_wts_L, max_thresh_L, min_thresh_L))
        if OpenPosLongs is not None:
            for S in OpenPosLongs:
                try:
                    if S in df_tgt_wts_L['symbols'].values:
                        if CurWtLong[S] > max_thresh_L[S] or CurWtLong[S] < min_thresh_L[S]:
                            return True
                    else:continue
                except: 
                    long_errors.append((S, get_datetime()))
        else:return 
    # --------
    RALL = check_target_longs(context, data)
    if RALL:                          
        for S in OpenPosLongs:
            try:
                stock_wt = df_tgt_wts_L.query('symbols==@S')['weights'].iat[0]
                order_target_percent(S, stock_wt * c.target_leverage)
            except: continue
    # _________________________________________________________ #              
    # rebalance to target shorts    
    short_errors=[]
    def check_target_shorts(context, data):
        """
        Function to test each stock's weight against the rebalance corridor. 
        If any stocks fall outside the band, send orders to rebalance the short portfolio
        """          
        print("Target Weights SHORTS: LevtgtWT={} | minus={} | plus={}".          
              format(df_tgt_wts_S, max_thresh_S, min_thresh_S))
        if OpenPosShorts is not None:
            for S in OpenPosShorts:
                try:
                    if S in df_tgt_wts_S['symbols'].values:
                        if CurWtShort[S] > max_thresh_S[S] or CurWtShort[S] < min_thresh_S[S]:
                            return True
                    else: continue
                except:
                    short_errors.append((S, get_datetime()))
        else: return
    RALL_S = check_target_shorts(context, data)
    if RALL_S:                        
        for S in OpenPosShorts:
            try:
                stock_wt = df_tgt_wts_S.query('symbols==@S')['weights'].iat[0]           
                order_target_percent(S, stock_wt * c.target_leverage)
            except: continue
    # _________________________________________________________ #    
    # List of all target symbols
    # if we have an open position but the stock is not a current target we liquidate the position
    target_symbols = list(df_tgt_wts_L['symbols']) + list(df_tgt_wts_S['symbols'])
    leftover_syms = [sym for sym in OpenPos if sym not in target_symbols]
    print('leftover syms:\n{}'.format([S.symbol for S in leftover_syms]))
    if len(leftover_syms)>0:
        for sym in leftover_syms:
            order_target_percent(sym, 0)
            print('> Liquidate Leftover Symbols: sid: {} | Timestamp: {}'.format(sym.symbol, get_datetime()))  
    return   
    # _________________________________________________________ #    
# ============================================================== #  
def portfolio_tracker(context, data):
    P = context.portfolio
    A = context.account

    PortV = P.portfolio_value
    PosV = P.positions_value
    MyCash = P.cash
    Positions = P.positions
    NPos = len(Positions.keys())
    Lev = A.leverage
    return PortV, PosV, MyCash, Positions, NPos, Lev 
# ============================================================== #          
def record_vars(context, data):    
    P = context.portfolio
    A = context.account    
    
    MyCash = P.cash
    PortV = P.portfolio_value    
    NPos = len(P.positions.keys())    
    record(N_Positions=NPos, CashPerC=(100*MyCash/PortV))
    record(Net_Leverage=A.net_leverage, Gross_Leverage=A.leverage)
    return
# ============================================================== # 
# Order tracking Logic lifted and modified from https://www.quantopian.com/posts/track-orders  
# ============================================================== # 
def track_orders_2(context, data):  # Log orders created, filled, unfilled or canceled.  
    '''      https://www.quantopian.com/posts/track-orders  
    Status:  
       0 - Unfilled  
       1 - Filled (can be partial)  
       2 - Canceled  
    '''  
    c = context  
    log_cash = 1    # Show cash values in logging window or not.  
    log_ids  = 0 #1    # Include order id's in logging window or not.

    ''' Start and stop date options ...  
    To not overwhelm the logging window, start/stop dates can be entered  
      either below or in initialize() if you move to there for better efficiency.  
    Example:  
        c.dates  = {  
            'active': 0,  
            'start' : ['2007-05-07', '2010-04-26'],  
            'stop'  : ['2008-02-13', '2010-11-15']  
        }  
    '''  
    if 'orders' not in c:  
        c.orders = {}               # Move these to initialize() for better efficiency.  
        c.dates  = {  
            'active': 0,  
            'start' : [],           # Start dates, option  
            'stop'  : []            # Stop  dates, option  
        }  
    else:
        c.dates  = {  
            'active': 0,  
            'start' : [],           # Start dates, option  
            'stop'  : []            # Stop  dates, option  
        } 
    from pytz import timezone       # Python only does once, makes this portable.  
                                    #   Move to top of algo for better efficiency.

    # If the dates 'start' or 'stop' lists have something in them, sets them.  
    if c.dates['start'] or c.dates['stop']:  
        date = str(get_datetime().date())  
        if   date in c.dates['start']:    # See if there's a match to start  
            c.dates['active'] = 1  
        elif date in c.dates['stop']:     #   ... or to stop  
            c.dates['active'] = 0  
    else:  
        c.dates['active'] = 1  # Set to active b/c no conditions

    if c.dates['active'] == 0:  
        return                 # Skip if off

    def _minute():   # To preface each line with the minute of the day.  
        if get_environment('data_frequency') == 'minute':  
            bar_dt = get_datetime().astimezone(timezone('US/Eastern'))  
            minute = (bar_dt.hour * 60) + bar_dt.minute - 570  # (-570 = 9:31a)  
            return str(minute).rjust(3)  
        return ''    # Daily mode, just leave it out.

    def _orders(to_log):    # So all logging comes from the same line number,  
        log.info(to_log)    #   for vertical alignment in the logging window.

    ordrs = c.orders.copy()    # Independent copy to allow deletes  
    for id in ordrs:  
        o    = get_order(id)  
        sec  = o.sid ; sym = sec.symbol  
        oid  = o.id if log_ids else ''  
        cash = 'cash {}'.format(int(c.portfolio.cash)) if log_cash else ''  
        if data.can_trade(sec):
            prc  = '%.2f' % data.current(sec, 'price')  
        else: 
            prc  = 'unknwn'  
        if o.filled:        # Filled at least some  
            trade  = 'Bot' if o.amount > 0 else 'Sold'  
            filled = '{}'.format(o.amount)  
            if o.filled == o.amount:    # complete  
                if 0 < c.orders[o.id] < o.amount:  
                    filled  = 'all/{}'.format(o.amount)  
                del c.orders[o.id]  
            else:  
                done_prv       = c.orders[o.id]       # previously filled ttl  
                filled_this    = o.filled - done_prv  # filled this time, can be 0  
                c.orders[o.id] = o.filled             # save for increments math  
                filled         = '{}/{}'.format(filled_this, o.amount)  
            _orders(' {}      {} {} {} at {}   {} {}'.format(_minute(),  
                trade, filled, sym, prc, cash, oid))  
        else:  
            canceled = 'canceled' if o.status == 2 else ''  
            _orders(' {}         {} {} unfilled {} {}'.format(_minute(),  
                    o.sid.symbol, o.amount, canceled, oid))  
            if canceled: del c.orders[o.id]

    for oo_list in get_open_orders().values(): # Open orders list  
        for o in oo_list:  
            sec  = o.sid ; sym = sec.symbol  
            oid  = o.id if log_ids else ''  
            cash = 'cash {}'.format(int(c.portfolio.cash)) if log_cash else ''  
            if data.can_trade(sec):
                prc  = '%.2f' % data.current(sec, 'price') 
            else: 
                prc  = 'unknwn' 
            if o.status == 2:                  # Canceled  
                _orders(' {}    Canceled {} {} order   {} {}'.format(_minute(),  
                        trade, o.amount, sym, prc, cash, oid))  
                del c.orders[o.id]  
            elif o.id not in c.orders:         # New  
                c.orders[o.id] = 0  
                trade = 'Buy' if o.amount > 0 else 'Sell'  
                if o.limit:                    # Limit order  
                    _orders(' {}   {} {} {} now {} limit {}   {} {}'.format(_minute(),  
                        trade, o.amount, sym, prc, o.limit, cash, oid))  
                elif o.stop:                   # Stop order  
                    _orders(' {}   {} {} {} now {} stop {}   {} {}'.format(_minute(),  
                        trade, o.amount, sym, prc, o.stop, cash, oid))  
                else:                          # Market order  
                    _orders(' {}   {} {} {} at {}   {} {}'.format(_minute(),  
                        trade, o.amount, sym, prc, cash, oid))  
# ============================================================== #