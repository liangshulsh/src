"""
Stocks are selected using k-means clustering to get a diversified portfolio. Uses L1 regularization term to sparsify the portfolio weights and achieve an all-long portfolio.

"""
import pandas as pd
import numpy as np
import cvxpy as cvx
import math
from quantopian.pipeline.data import morningstar
from quantopian.pipeline.filters.morningstar import Q1500US
from quantopian.pipeline import Pipeline
from quantopian.algorithm import attach_pipeline, pipeline_output
from sklearn.cluster import KMeans


def initialize(context):
    
    # Initialize quarterly counter
    context.iMonths=0
    context.NMonths=3  # <- Sets quarterly rebalancing counter
    
    # Set the slippage model
    set_slippage(slippage.VolumeShareSlippage(volume_limit=0.025, price_impact=0.1))
    
    # Set the commission model (Interactive Brokers Commission)
    set_commission(commission.PerShare(cost=0.0075, min_trade_cost=1.0))
    
    # Attach pipeline
    my_pipe = make_pipeline()
    attach_pipeline(my_pipe, 'fundamental_line')
    
    # Place order according to n-month counter
    schedule_function(cluster_analysis,
                      date_rules.month_start(),
                      time_rules.market_open(hours=1, minutes=30))
    
    schedule_function(calculate_weights,
                      date_rules.month_start(),
                      time_rules.market_open(hours=1, minutes=30))
    
    schedule_function(place_order,
                      date_rules.month_start(),
                      time_rules.market_open(hours=1, minutes=30))
    
    # Record tracking variables at the end of each day.
    schedule_function(record_vars,
                      date_rules.every_day(),
                      time_rules.market_close(minutes=1))
    
       
def before_trading_start(context, data):
    
    # Pipeline_output returns the constructed dataframe.
    context.output = pipeline_output('fundamental_line')
       
def make_pipeline():

    # Get fundamental data from liquid universe for easier trades
    my_assets = morningstar.balance_sheet.total_assets.latest
    my_revenues = morningstar.income_statement.total_revenue.latest
    my_income = morningstar.cash_flow_statement.net_income.latest

    pipe = Pipeline(
              columns={
                'total_assets': my_assets,
                'total_revenues': my_revenues,
                'net_income': my_income,
              },
              screen = Q1500US()
          )
    
    return pipe

def cluster_analysis(context, data):
    
    # Get list of equities that made it through the pipeline
    context.output = context.output.dropna(axis=0, how='any')
    equity_list = []
    for i in range(len(context.output)):
        meh = context.output.index[i]
        equity_list.append(meh)
       
    # Get feature matrix
    x = np.zeros((len(context.output),1))
    for i in range(len(context.output)):
        weighted_netincome = context.output.iloc[i,0] / context.output.iloc[i,1]
        weighted_revenues = context.output.iloc[i,2] / context.output.iloc[i,1]
        x[i] = 0.5 * weighted_netincome + 0.5 * weighted_revenues
            
    context.x = pd.DataFrame(data=x.T, columns=equity_list)
    
    # Run k-means on feature matrix
    n_clust = 30
    alg = KMeans(n_clusters=n_clust, random_state=10, n_jobs=-1)
    context.results = alg.fit_predict(x)
    
    # Get rolling window of past prices and compute returns
    prices = data.history(assets=equity_list, fields='price', bar_count=100, frequency='1d').dropna()
    context.returns_ = prices.pct_change().dropna()
    
    # Make pandas Series of clusters to reference tickers
    cluster_list = pd.Series(data=context.results, index=equity_list)
    
    # Calculate expected returns and Sharpes
    mus = np.mean(context.returns_, axis=1)
    sharpes = mus / np.std(context.returns_, axis=1)
    
    # Choose stocks with highest Sharpe ratio from each cluster
    context.best_equities = []
    max_equity = None
    for i in range(n_clust):
        counter_1 = i
        counter_2 = -100
        for j in range(len(sharpes)):
			if cluster_list.iloc[j]==counter_1:
				if sharpes[j]>counter_2:
					counter_2 = sharpes[j]
					max_equity = cluster_list.index[j]
    	context.best_equities.append(max_equity)
    
    # Prevent same equities from getting ordered multiple times
    context.best_equities = set(context.best_equities)
    print("best equities", context.best_equities)
    print("num of best securities", len(context.best_equities))
    
                    
def calculate_weights(context, data):
    """
    This rebalancing function is called every 3 months (quarterly).
    """
    # Drop equities that didn't make it through pipeline with equity_list
    context.returns_ = context.returns_.T
    bad_list = []
    for row in list(context.returns_.T):
        if row not in context.best_equities:
            bad_list.append(row)
    
    context.returns_ = context.returns_.drop(labels=bad_list)
    context.order_list = list(context.returns_.T)
    print("The order list", context.order_list)
    print("num of remaining securities", len(context.returns_))
    
    # Calculate expected returns
    context.returns_ = np.asmatrix(context.returns_)
    mus = np.mean(context.returns_, axis=1)
    
    # Penalization parameter
    gamma = 2

	# Convert to cvxpy matrix and solve optimization problem
    n = len(mus)
    w = cvx.Variable(n)
    R_weighted = w.T*context.returns_
    mus = mus.T*w

    cost = cvx.sum_squares(mus-R_weighted) + gamma * cvx.norm(w, 1)
    my_problem = cvx.Problem(cvx.Minimize(cost), [w.T*np.ones((n,))==1])
    opt_value = my_problem.solve()
    context.weights = np.asarray(w.value)
    context.weights_list = pd.Series(list(context.weights), context.order_list)
        
    
def place_order(context,data):
    
    context.iMonths += 1
    if (context.iMonths % context.NMonths) != 1:
        return

    for stock in context.order_list:
            if data.can_trade(stock):
                order_target_percent(stock, context.weights_list[stock])
                
def record_vars(context, data):
    
    record(leverage=context.account.leverage, my_return=context.portfolio.returns)
               