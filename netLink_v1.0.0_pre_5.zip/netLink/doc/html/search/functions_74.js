var searchData=
[
  ['type',['type',['../class_n_l_1_1_socket.html#aa7b25c5e68c4fa7419b50dea9b3e306d',1,'NL::Socket']]]
];
