var searchData=
[
  ['tcp',['TCP',['../namespace_n_l.html#ad2585e7dc8b914b6016fc4698d82e08ea4a4a122ff65d867264f5d6f5196de954',1,'NL']]],
  ['type',['type',['../class_n_l_1_1_socket.html#aa7b25c5e68c4fa7419b50dea9b3e306d',1,'NL::Socket']]]
];
