var searchData=
[
  ['read',['read',['../class_n_l_1_1_smart_buffer.html#abb25b6f9ab458ee2eadde5f42c377f4e',1,'NL::SmartBuffer::read()'],['../class_n_l_1_1_socket.html#ad116a12c17b541769143aca08497e313',1,'NL::Socket::read()']]],
  ['readfrom',['readFrom',['../class_n_l_1_1_socket.html#ac1e4df92265c8615288b921412bea182',1,'NL::Socket']]],
  ['remove',['remove',['../class_n_l_1_1_socket_group.html#a02e4e87e214a05ae5d3b2046c6d596ce',1,'NL::SocketGroup::remove(unsigned index)'],['../class_n_l_1_1_socket_group.html#aa03841a8978bbaa6223f11b994f42d90',1,'NL::SocketGroup::remove(Socket *socket)']]]
];
