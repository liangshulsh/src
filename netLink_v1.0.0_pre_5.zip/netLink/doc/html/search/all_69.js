var searchData=
[
  ['init',['init',['../namespace_n_l.html#a33d47421bd2e2106acc1a0df62bfa7ad',1,'NL']]],
  ['ip4',['IP4',['../namespace_n_l.html#adda95837128bcd5308d60a6485b021f0afa4684ea5d403a2d499fb66725f8b01a',1,'NL']]],
  ['ip6',['IP6',['../namespace_n_l.html#adda95837128bcd5308d60a6485b021f0af80bdf9494afe1a15a58eb231e2932b6',1,'NL']]],
  ['ipver',['ipVer',['../class_n_l_1_1_socket.html#af395d491f3d8b0eee97365dc57712336',1,'NL::Socket::ipVer()'],['../namespace_n_l.html#adda95837128bcd5308d60a6485b021f0',1,'NL::IPVer()']]]
];
