var searchData=
[
  ['disconnect',['disconnect',['../class_n_l_1_1_socket.html#ac2704e920edeb477ca7b5e1b8f308b0f',1,'NL::Socket']]]
];
