var searchData=
[
  ['core_2eh',['core.h',['../core_8h.html',1,'']]]
];
