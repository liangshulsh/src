﻿using System.Collections.Generic;
using System.Net;

namespace BrokerWinForm
{
    public class Subscriber
    {

        public IPEndPoint IpEndPoint;
        public List<EventData> Events;
    }
}
